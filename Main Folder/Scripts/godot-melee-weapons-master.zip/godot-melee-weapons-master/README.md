# godot-melee-weapons
How to make melee weapons in Godot game engine
